If u want to close it, close it with ctrl+c to save!
And open it in a Folder.